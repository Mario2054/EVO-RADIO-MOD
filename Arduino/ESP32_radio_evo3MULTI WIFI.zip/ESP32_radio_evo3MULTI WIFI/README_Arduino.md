# ESP32 Radio EVO3 — Konfiguracja Arduino IDE 2.x

## Struktura projektu
```
ESP32_radio_evo3/
├── ESP32_radio_evo3.ino   ← główny sketch (main.cpp z PlatformIO)
├── partitions.csv          ← tabela partycji 16MB
├── bt/                     ← moduł Bluetooth WebUI
├── core/                   ← flagi funkcji (options.h, config.h)
├── network/                ← moduł DLNA
├── SDPlayer/               ← odtwarzacz plików z karty SD
├── SDRecorder/             ← nagrywarka strumienia radiowego
├── sdcard/                 ← pliki webUI (HTML/CSS/JS) na kartę SD
├── APMS_GraphicEQ16.cpp/h  ← equalizer 16-pasmowy
├── EQ_FFTAnalyzer.cpp/h    ← analizator FFT
├── EQ_AnalyzerDisplay.cpp/h
├── EQ16_GraphicEQ.h
├── WebUIManager.cpp/h
├── wifi_animation.cpp/h
├── audio_hooks.cpp
└── vu_style11.cpp/h
```

---

## Wymagane biblioteki (Arduino IDE Library Manager)

| Biblioteka | Wersja | Źródło |
|---|---|---|
| ESP32-audioI2S | 3.4.5 | GitHub: schreibfaul1/ESP32-audioI2S (tag 3.4.5) |
| ESPAsyncWebServer | 3.7.7 | Arduino Library Manager: ESP32Async/ESPAsyncWebServer |
| AsyncTCP | 3.4.1 | Arduino Library Manager: ESP32Async/AsyncTCP |
| ArduinoJson | 6.21.x | Arduino Library Manager |
| U8g2 | 2.36.x | Arduino Library Manager |
| WiFiManager | 2.0.17 | Arduino Library Manager (tzapu) |
| ezButton | 1.0.6 | Arduino Library Manager |

### Instalacja ESP32-audioI2S z GitHub:
1. Pobierz ZIP: https://github.com/schreibfaul1/ESP32-audioI2S/archive/refs/tags/3.4.5.zip
2. W Arduino IDE: **Sketch → Include Library → Add .ZIP Library...**

---

## Konfiguracja płytki (Tools menu)

| Ustawienie | Wartość |
|---|---|
| Board | **ESP32S3 Dev Module** (lub 4D Systems GEN4-ESP32S3 jeśli dostępna) |
| Flash Size | **16MB (128Mb)** |
| Partition Scheme | **Custom** → wskaż `partitions.csv` z tego folderu* |
| Flash Mode | **QIO 80MHz** |
| PSRAM | **OPI PSRAM** |
| CPU Frequency | **240MHz** |
| Arduino USB Mode | **Hardware CDC and JTAG** |
| USB CDC On Boot | **Disabled** |
| Upload Speed | 921600 |
| Port | COM9 (lub właściwy port) |

> *Kopiowanie `partitions.csv` do niestandardowej lokalizacji partycji:
> `C:\Users\<user>\AppData\Local\Arduino15\packages\esp32\hardware\esp32\<wersja>\tools\partitions\`
> Lub użyj PlatformIO dla pełnej kontroli nad partycjami.

---

## Flagi kompilacji (build flags)

W Arduino IDE dodaj je przez **sketch.json** lub przez modyfikację `platform.local.txt`.

Najważniejsze flagi używane w projekcie:
```
-DENABLE_FFT_ANALYZER=1
-DENABLE_EQ16=1
-DBOARD_HAS_PSRAM
-DCONFIG_SPIRAM_CACHE_WORKAROUND
-DCONFIG_SPIRAM_USE=1
-DCONFIG_SPIRAM_SUPPORT=1
-mfix-esp32-psram-cache-issue
-O2
-ffast-math
```

---

## Włączanie/wyłączanie funkcji

Edytuj plik `core/options.h`:
```cpp
// Włącz DLNA:
#define USE_DLNA

// Włącz/wyłącz equalizer 16-pasmowy:
#define ENABLE_EQ16 1  // 1=włączony, 0=wyłączony

// Włącz analizator FFT w ESP32_radio_evo3.ino:
// -DENABLE_FFT_ANALYZER=1 (flaga w build_flags)
```

---

## Uwaga: Arduino IDE vs PlatformIO

Projekt był pierwotnie opracowany i testowany w **PlatformIO** (zalecane środowisko).
Arduino IDE 2.x obsługuje podfoldery w sketchu, jednak:
- Brak automatycznej obsługi `partitions.csv` — wymaga ręcznej konfiguracji
- Flagi kompilacji (`build_flags`) wymagają dodatkowej konfiguracji
- Długie ścieżki na Windows mogą powodować problemy — włącz: *Zasady grupy → System → Filesystem → Enable Win32 long paths*

**PlatformIO** (VS Code) jest rekomendowane dla pełnej kontroli nad budowaniem projektu.
